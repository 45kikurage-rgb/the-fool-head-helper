package com.thefoolhead.helper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final String PREFS = "the_fool_head_helper";
    static final String SHARE_KEY = "share_key";
    private static final String MANAGEMENT_SITE = "https://the-fool-head.45kikurage.workers.dev";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button accessibility = findViewById(R.id.openAccessibility);
        Button site = findViewById(R.id.openSite);
        Button saveKey = findViewById(R.id.saveShareKey);
        EditText shareKey = findViewById(R.id.shareKeyInput);
        TextView status = findViewById(R.id.statusText);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        String savedKey = prefs.getString(SHARE_KEY, "");
        shareKey.setText(savedKey);
        if (savedKey.matches("\\d{8}")) {
            status.setText("共有キーを設定済みです。Fを開くたびに定型文を取得します。");
        }

        saveKey.setOnClickListener(v -> {
            String key = shareKey.getText().toString().trim();
            if (!key.matches("\\d{8}")) {
                shareKey.setError("8桁の数字で入力してください");
                return;
            }
            prefs.edit().putString(SHARE_KEY, key).apply();
            status.setText("共有キーを保存しました。Fを開くと最新版を取得します。");
            Toast.makeText(this, "共有キーを保存しました", Toast.LENGTH_SHORT).show();
        });

        accessibility.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });

        site.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(MANAGEMENT_SITE));
            startActivity(i);
        });
    }
}
