package com.thefoolhead.helper;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FoolAccessibilityService extends AccessibilityService {
    private static final String SITE = "https://the-fool-head.45kikurage.workers.dev";
    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private AccessibilityNodeInfo lastEditableNode;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) return;

        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_FOCUSED && source.isEditable()) {
            rememberEditable(source);
        } else if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED && source.isEditable()) {
            rememberEditable(source);
        }
    }

    private void rememberEditable(AccessibilityNodeInfo node) {
        if (lastEditableNode != null) {
            try { lastEditableNode.recycle(); } catch (Exception ignored) {}
        }
        try {
            lastEditableNode = AccessibilityNodeInfo.obtain(node);
        } catch (Exception e) {
            lastEditableNode = node;
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        removePanel();
        removeBubble();
        if (lastEditableNode != null) {
            try { lastEditableNode.recycle(); } catch (Exception ignored) {}
            lastEditableNode = null;
        }
        super.onDestroy();
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke((int) dp(2), Color.rgb(55, 65, 70));
        return d;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                width,
                height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    private void showBubble() {
        if (bubble != null || windowManager == null) return;

        TextView b = new TextView(this);
        b.setText("F");
        b.setTextSize(21);
        b.setTextColor(Color.BLACK);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(Color.rgb(255, 246, 190), 28));

        int size = (int) dp(56);
        WindowManager.LayoutParams p = overlayParams(size, size);
        p.x = (int) dp(8);
        p.y = (int) dp(180);

        final float[] downRaw = new float[2];
        final int[] downPos = new int[2];
        final boolean[] moved = new boolean[1];

        b.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRaw[0] = event.getRawX();
                    downRaw[1] = event.getRawY();
                    downPos[0] = p.x;
                    downPos[1] = p.y;
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downRaw[0];
                    float dy = event.getRawY() - downRaw[1];
                    if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved[0] = true;
                    p.x = downPos[0] + (int) dx;
                    p.y = downPos[1] + (int) dy;
                    try { windowManager.updateViewLayout(b, p); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) showPhrasePanel();
                    return true;
            }
            return false;
        });

        bubble = b;
        windowManager.addView(bubble, p);
    }

    private void removeBubble() {
        if (bubble != null && windowManager != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
    }

    private void showPhrasePanel() {
        if (panel != null || windowManager == null) return;

        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(rounded(Color.WHITE, 18));

        WebView web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setBackgroundColor(Color.WHITE);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PhraseBridge(), "AndroidPhrase");

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextSize(24);
        close.setTextColor(Color.BLACK);
        close.setGravity(Gravity.CENTER);
        close.setBackground(rounded(Color.rgb(255, 225, 225), 20));

        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        frame.addView(web, webLp);

        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(
                (int) dp(46), (int) dp(46), Gravity.TOP | Gravity.END
        );
        closeLp.setMargins(0, (int) dp(6), (int) dp(6), 0);
        frame.addView(close, closeLp);
        close.setOnClickListener(v -> removePanel());

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                handler.postDelayed(() -> preparePhraseWeb(view), 700);
            }
        });

        int width = getResources().getDisplayMetrics().widthPixels - (int) dp(20);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.72f);
        WindowManager.LayoutParams p = overlayParams(width, height);
        p.x = (int) dp(10);
        p.y = (int) (getResources().getDisplayMetrics().heightPixels * 0.10f);

        panel = frame;
        windowManager.addView(panel, p);
        web.loadUrl(SITE);
    }

    private void preparePhraseWeb(WebView web) {
        String js =
                "(function(){" +
                "try{" +
                "var b=document.querySelector('.navbtn[data-view=\"phraseView\"]');" +
                "if(b){b.click();}" +
                "document.querySelectorAll('header,.bottomnav').forEach(function(x){x.style.display='none';});" +
                "document.querySelectorAll('.view').forEach(function(x){if(x.id!=='phraseView')x.style.display='none';});" +
                "var pv=document.getElementById('phraseView');if(pv){pv.style.display='block';pv.classList.add('active');}" +
                "document.querySelectorAll('.phrase-card-name').forEach(function(x){x.contentEditable='false';});" +
                "document.querySelectorAll('.phrase-card-text').forEach(function(t){" +
                "t.readOnly=true;t.style.cursor='pointer';" +
                "t.addEventListener('click',function(e){" +
                "e.preventDefault();e.stopPropagation();" +
                "AndroidPhrase.choose(t.value||'');" +
                "},true);" +
                "});" +
                "}catch(e){}" +
                "})();";
        web.evaluateJavascript(js, null);
    }

    private void removePanel() {
        if (panel != null && windowManager != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
    }

    private class PhraseBridge {
        @JavascriptInterface
        public void choose(String text) {
            if (text == null || text.isEmpty()) return;
            handler.post(() -> {
                removePanel();
                handler.postDelayed(() -> insertIntoLastField(text), 180);
            });
        }
    }

    private void insertIntoLastField(String text) {
        AccessibilityNodeInfo target = findBestEditableNode();

        if (target != null) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            boolean ok = false;
            try {
                ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            } catch (Exception ignored) {}

            if (ok) {
                Toast.makeText(this, "定型文を入力しました", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("THE fool head", text));

        if (target != null) {
            boolean pasted = false;
            try {
                pasted = target.performAction(AccessibilityNodeInfo.ACTION_PASTE);
            } catch (Exception ignored) {}
            if (pasted) {
                Toast.makeText(this, "定型文を貼り付けました", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        Toast.makeText(this, "直接入力できなかったためクリップボードへコピーしました", Toast.LENGTH_LONG).show();
    }

    private AccessibilityNodeInfo findBestEditableNode() {
        if (lastEditableNode != null) {
            try {
                if (lastEditableNode.refresh() && lastEditableNode.isEditable()) {
                    return lastEditableNode;
                }
            } catch (Exception ignored) {}
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            try {
                AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                if (focused != null && focused.isEditable()) return focused;
            } catch (Exception ignored) {}
        }
        return null;
    }
}
