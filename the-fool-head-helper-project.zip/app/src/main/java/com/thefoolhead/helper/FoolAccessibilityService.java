package com.thefoolhead.helper;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FoolAccessibilityService extends AccessibilityService {
    private static final String API_URL =
            "https://the-fool-shared-api.45kikurage.workers.dev/api/clipboard";
    private static final String CACHE_KEY = "cached_phrases";
    private static final String CACHE_UPDATED_AT = "cached_phrases_updated_at";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private LinearLayout phraseList;
    private TextView phraseStatus;
    private AccessibilityNodeInfo lastEditableNode;

    private static class Phrase {
        final String name;
        final String text;

        Phrase(String name, String text) {
            this.name = name;
            this.text = text;
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getSource() == null) return;
        AccessibilityNodeInfo source = event.getSource();
        if ((event.getEventType() == AccessibilityEvent.TYPE_VIEW_FOCUSED
                || event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED)
                && source.isEditable()) {
            rememberEditable(source);
        }
    }

    private void rememberEditable(AccessibilityNodeInfo node) {
        if (lastEditableNode != null) {
            try { lastEditableNode.recycle(); } catch (Exception ignored) {}
        }
        try { lastEditableNode = AccessibilityNodeInfo.obtain(node); }
        catch (Exception error) { lastEditableNode = node; }
    }

    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        removePanel();
        removeBubble();
        networkExecutor.shutdownNow();
        if (lastEditableNode != null) {
            try { lastEditableNode.recycle(); } catch (Exception ignored) {}
            lastEditableNode = null;
        }
        super.onDestroy();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke((int) dp(2), Color.rgb(55, 65, 70));
        return drawable;
    }

    private WindowManager.LayoutParams overlayParams(int width, int height, boolean focusable) {
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!focusable) flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width, height, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        return params;
    }

    private void showBubble() {
        if (bubble != null || windowManager == null) return;
        TextView button = new TextView(this);
        button.setText("F");
        button.setTextSize(21);
        button.setTextColor(Color.BLACK);
        button.setGravity(Gravity.CENTER);
        button.setBackground(rounded(Color.rgb(255, 246, 190), 28));

        int size = (int) dp(56);
        WindowManager.LayoutParams params = overlayParams(size, size, false);
        params.x = (int) dp(8);
        params.y = (int) dp(180);
        float[] down = new float[2];
        int[] start = new int[2];
        boolean[] moved = new boolean[1];

        button.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = event.getRawX(); down[1] = event.getRawY();
                    start[0] = params.x; start[1] = params.y; moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - down[0];
                    float dy = event.getRawY() - down[1];
                    if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved[0] = true;
                    params.x = start[0] + (int) dx; params.y = start[1] + (int) dy;
                    try { windowManager.updateViewLayout(button, params); }
                    catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) showPhrasePanel();
                    return true;
                default: return false;
            }
        });
        bubble = button;
        windowManager.addView(bubble, params);
    }

    private void removeBubble() {
        if (bubble != null && windowManager != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
    }

    private TextView textView(String text, float size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(Color.rgb(32, 42, 48));
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }

    private void showPhrasePanel() {
        if (panel != null || windowManager == null) return;
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(rounded(Color.rgb(255, 253, 242), 18));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding((int) dp(12), (int) dp(10), (int) dp(12), (int) dp(12));
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = textView("定型文", 20, true);
        header.addView(title, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button refresh = new Button(this);
        refresh.setText("更新"); refresh.setTextSize(13); refresh.setAllCaps(false);
        header.addView(refresh, new LinearLayout.LayoutParams((int) dp(72), (int) dp(46)));
        Button close = new Button(this);
        close.setText("×"); close.setTextSize(20); close.setAllCaps(false);
        LinearLayout.LayoutParams closeParams =
                new LinearLayout.LayoutParams((int) dp(50), (int) dp(46));
        closeParams.setMargins((int) dp(6), 0, 0, 0);
        header.addView(close, closeParams);
        root.addView(header);

        phraseStatus = textView("端末内データを表示しています", 12, false);
        root.addView(phraseStatus);
        ScrollView scroll = new ScrollView(this);
        phraseList = new LinearLayout(this);
        phraseList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(phraseList);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        frame.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        close.setOnClickListener(view -> removePanel());
        refresh.setOnClickListener(view -> fetchLatestPhrases());
        int width = getResources().getDisplayMetrics().widthPixels - (int) dp(20);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.72f);
        WindowManager.LayoutParams params = overlayParams(width, height, true);
        params.x = (int) dp(10);
        params.y = (int) (getResources().getDisplayMetrics().heightPixels * 0.10f);
        panel = frame;
        windowManager.addView(panel, params);

        renderPhrases(loadCachedPhrases());
        fetchLatestPhrases();
    }

    private void removePanel() {
        if (panel != null && windowManager != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
        }
        panel = null; phraseList = null; phraseStatus = null;
    }

    private List<Phrase> parsePhrases(JSONArray array) {
        List<Phrase> result = new ArrayList<>();
        if (array == null) return result;
        for (int index = 0; index < Math.min(array.length(), 100); index++) {
            JSONObject item = array.optJSONObject(index);
            if (item == null) continue;
            String text = item.optString("text", "");
            if (!text.isEmpty()) result.add(new Phrase(
                    item.optString("name", "定型文" + (index + 1)), text));
        }
        return result;
    }

    private List<Phrase> loadCachedPhrases() {
        try { return parsePhrases(new JSONArray(prefs().getString(CACHE_KEY, "[]"))); }
        catch (Exception ignored) { return new ArrayList<>(); }
    }

    private void renderPhrases(List<Phrase> phrases) {
        if (phraseList == null) return;
        phraseList.removeAllViews();
        if (phrases.isEmpty()) {
            TextView empty = textView("定型文がありません。\nTHE fool headから送信してください。", 16, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, (int) dp(40), 0, (int) dp(40));
            phraseList.addView(empty);
            return;
        }
        for (Phrase phrase : phrases) {
            Button button = new Button(this);
            button.setText(phrase.name + "\n" + phrase.text);
            button.setTextSize(15); button.setAllCaps(false);
            button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            button.setBackground(rounded(Color.WHITE, 12));
            button.setOnClickListener(view -> choosePhrase(phrase.text));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, (int) dp(7), 0, 0);
            phraseList.addView(button, params);
        }
    }

    private void fetchLatestPhrases() {
        String key = prefs().getString(MainActivity.SHARE_KEY, "").trim();
        if (!key.matches("\\d{8}")) {
            showStatus("アプリ本体で8桁の共有キーを設定してください", true);
            return;
        }
        showStatus("最新版を取得中…", false);
        networkExecutor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(API_URL).openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-Share-Key", key);
                connection.setRequestProperty("Accept", "application/json");
                connection.setConnectTimeout(8000); connection.setReadTimeout(8000);
                connection.setUseCaches(false);
                int status = connection.getResponseCode();
                String body = readStream(status >= 200 && status < 300
                        ? connection.getInputStream() : connection.getErrorStream());
                if (status < 200 || status >= 300) {
                    String message = "通信エラー " + status;
                    try {
                        String apiError = new JSONObject(body).optString("error", "");
                        if (!apiError.isEmpty()) message = apiError;
                    } catch (Exception ignored) {}
                    throw new Exception(message);
                }
                JSONObject payload = new JSONObject(body);
                JSONArray array = payload.optJSONArray("phrases");
                if (array == null) array = new JSONArray();
                List<Phrase> latest = parsePhrases(array);
                prefs().edit().putString(CACHE_KEY, array.toString())
                        .putString(CACHE_UPDATED_AT, payload.optString("updatedAt", "")).apply();
                handler.post(() -> {
                    if (panel == null) return;
                    renderPhrases(latest);
                    showStatus("最新版を取得しました", false);
                    if (phraseStatus != null) phraseStatus.setTextColor(Color.rgb(8, 120, 42));
                });
            } catch (Exception error) {
                handler.post(() -> {
                    if (panel == null) return;
                    String savedAt = prefs().getString(CACHE_UPDATED_AT, "");
                    showStatus("取得できませんでした。端末内データを表示します"
                            + (savedAt.isEmpty() ? "" : "（前回取得分）"), true);
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void showStatus(String text, boolean error) {
        if (phraseStatus == null) return;
        phraseStatus.setText(text);
        phraseStatus.setTextColor(error ? Color.rgb(190, 35, 35) : Color.rgb(70, 85, 95));
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
        }
        return result.toString();
    }

    private void choosePhrase(String text) {
        if (text == null || text.isEmpty()) return;
        removePanel();
        handler.postDelayed(() -> insertIntoLastField(text), 180);
    }

    private void insertIntoLastField(String text) {
        AccessibilityNodeInfo target = findBestEditableNode();
        if (target != null) {
            Bundle args = new Bundle();
            args.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            try {
                if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                    Toast.makeText(this, "定型文を入力しました", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception ignored) {}
        }

        ClipboardManager clipboard =
                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("THE fool head", text));
        if (target != null) {
            try {
                if (target.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
                    Toast.makeText(this, "定型文を貼り付けました", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "直接入力できなかったためクリップボードへコピーしました",
                Toast.LENGTH_LONG).show();
    }

    private AccessibilityNodeInfo findBestEditableNode() {
        if (lastEditableNode != null) {
            try {
                if (lastEditableNode.refresh() && lastEditableNode.isEditable()) {
                    return lastEditableNode;
                }
            } catch (Exception ignored) {}
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            try {
                AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                if (focused != null && focused.isEditable()) return focused;
            } catch (Exception ignored) {}
        }
        return null;
    }
}
