# THE fool head Android補助アプリ v0.2

## 目的
他アプリの入力欄にカーソルを合わせた後、
フローティングアイコン「F」からTHE fool headの定型文を開き、
定型文本文をタップすると元の入力欄へ文字を入力します。

## 動作
1. APKをインストール
2. アプリを開く
3. 「ユーザー補助設定を開く」
4. 「THE fool head 定型文入力」をON
5. 画面端に F アイコンが表示
6. LINE / Chrome / ChatGPTなどの入力欄をタップ
7. F をタップ
8. 定型文本文をタップ
9. 定型文画面を閉じ、直前の入力欄へ入力

## 入力フォールバック
1. Accessibility ACTION_SET_TEXT
2. Clipboard + ACTION_PASTE
3. どちらも失敗した場合はクリップボードへコピー

## Web URL
https://the-fool-head.45kikurage.workers.dev

## GitHub Actions
このプロジェクトZIPをGitHubへ置き、
同梱の build-apk.yml を `.github/workflows/build-apk.yml` として作成すると、
GitHub Actionsから debug APK を作成できます。


## v0.2
フローティングWeb画面をフォーカス可能に変更し、共有キー・認証コード等の入力欄でソフトキーボードを使用できるよう修正。
