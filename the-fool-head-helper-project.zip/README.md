# THE fool head Android補助アプリ v0.3

## 目的
他アプリの入力欄にカーソルを合わせた後、
フローティングアイコン「F」から共通APIの定型文一覧を開き、
定型文本文をタップすると元の入力欄へ文字を入力します。

## 動作
1. APKをインストール
2. アプリを開く
3. THE fool headで使用中の8桁共有キーを入力して保存
4. 「ユーザー補助設定を開く」
5. 「THE fool head 定型文入力」をON
6. 画面端に F アイコンが表示
7. LINE / Chrome / ChatGPTなどの入力欄をタップ
8. F をタップ（開くたびに最新版を自動取得）
9. 定型文をタップ
10. 定型文画面を閉じ、直前の入力欄へ入力

通信できない場合は、前回取得して端末内に保存した定型文を表示します。

## 入力フォールバック
1. Accessibility ACTION_SET_TEXT
2. Clipboard + ACTION_PASTE
3. どちらも失敗した場合はクリップボードへコピー

## API URL
https://the-fool-shared-api.45kikurage.workers.dev/api/clipboard

## GitHub Actions
このプロジェクトZIPをGitHubへ置き、
同梱の build-apk.yml を `.github/workflows/build-apk.yml` として作成すると、
GitHub Actionsから debug APK を作成できます。


## v0.2
フローティングWeb画面をフォーカス可能に変更し、共有キー・認証コード等の入力欄でソフトキーボードを使用できるよう修正。

## v0.3
WebサイトのHTML表示とDOM参照を廃止。共通APIから定型文だけを直接取得し、端末内キャッシュを使えるよう変更。
